#!/usr/bin/env python
# coding: utf-8

# In[149]:


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)



import os

        
import warnings
warnings.filterwarnings("ignore")
import seaborn as sns


# # 1. Reading data

# In[146]:


app_data= pd.read_csv('application_data.csv')
prev_data= pd.read_csv('previous_applicationH.csv')


# In[72]:


app_data.head()


# In[147]:


prev_data.head()


# In[73]:


app_data.shape


# In[74]:


app_data.info()


# # 2. DATA CLEANING AND IMPUTING MISSING VALUES

# ## a. Find null values for each column and removing columns with null >40%

# In[75]:


Find_null = app_data.isnull().sum()/len(app_data)*100
Find_null.sort_values(ascending = False).head(50)


# ### **Since a lot of columns have rows with more than 40 percentage of values as null, it will be wise to drop them.

# In[76]:


Remove_null = Find_null.sort_values(ascending = False)
Remove_null = Remove_null[Remove_null.values > 40]
len(Remove_null)


# In[77]:


remove_list = Remove_null.index.tolist()
app_data.drop(labels =remove_list,axis =1,inplace=True)
app_data.shape


# ### **We have reduced the number of columns from 122 to 73

# ### **Now we have dealt with the > 40% null values, we will now take care of null values which are in less than <=20%. We will be imputing the values, but will try to find values with which it can be imputed at a later point of time.

# In[78]:


#inputing values for rest of columns where applicable
impute_columns = Find_null[(Find_null<=20) & (Find_null>0)].sort_values(ascending=False)
impute_columns


# ### **We don't know about the relevance of EXIT Source 3 column,and many columns have the null value percentage b/w 0-1 so, we can impute them, but for the ones with null values around 13, we can check them individually. 

# In[79]:


#Checking few columns to see if they can be imputed
app_data[['AMT_REQ_CREDIT_BUREAU_YEAR','AMT_REQ_CREDIT_BUREAU_MON','AMT_REQ_CREDIT_BUREAU_WEEK','AMT_REQ_CREDIT_BUREAU_DAY','AMT_REQ_CREDIT_BUREAU_HOUR','AMT_REQ_CREDIT_BUREAU_QRT']].info()


# ### **Let's look at AMT_REQ_CREDIT_BUREAU_YEAR data first and see

# In[80]:


app_data.AMT_REQ_CREDIT_BUREAU_YEAR.value_counts()


# ### **There does't seem to be many possible values for the above column, and seems to be categorical data, so we can impute the null values with the mode.

# In[81]:


app_data.AMT_REQ_CREDIT_BUREAU_YEAR.mode()


# ### **Same as column 'AMT_REQ_CREDIT_BUREAU_YEAR', we can impute the missing values of columns 'AMT_REQ_CREDIT_BUREAU_MONTH', 'AMT_REQ_CREDIT_BUREAU_WEEK', 'AMT_REQ_CREDIT_BUREAU_DAY', 'AMT_REQ_CREDIT_BUREAU_HOUR', 'AMT_REQ_CREDIT_BUREAU_QRT' with the mode as they are similar categories i.e number of enquiries. Let's find mode of each category.
# 
# 

# In[82]:


app_data.AMT_REQ_CREDIT_BUREAU_MON.mode()


# In[83]:


app_data.AMT_REQ_CREDIT_BUREAU_WEEK.mode()


# In[84]:


app_data.AMT_REQ_CREDIT_BUREAU_DAY.mode()


# In[85]:


app_data.AMT_REQ_CREDIT_BUREAU_HOUR.mode()


# In[86]:


app_data.AMT_REQ_CREDIT_BUREAU_QRT.mode()


# ### **We can easily impute the values mentioned in the above mode of different columns with 0.

# ### Checking the columns with "DAY" parameter

# ### **Since some of the values are negative and we cannot have days in negative 

# In[87]:


app_data['AMT_REQ_CREDIT_BUREAU_MON'] = app_data['AMT_REQ_CREDIT_BUREAU_MON'].fillna(0)
app_data['AMT_REQ_CREDIT_BUREAU_WEEK'] = app_data['AMT_REQ_CREDIT_BUREAU_WEEK'].fillna(0)
app_data['AMT_REQ_CREDIT_BUREAU_DAY'] = app_data['AMT_REQ_CREDIT_BUREAU_DAY'].fillna(0)
app_data['AMT_REQ_CREDIT_BUREAU_HOUR'] = app_data['AMT_REQ_CREDIT_BUREAU_HOUR'].fillna(0)
app_data['AMT_REQ_CREDIT_BUREAU_QRT'] = app_data['AMT_REQ_CREDIT_BUREAU_QRT'].fillna(0)
app_data['AMT_REQ_CREDIT_BUREAU_YEAR'] = app_data['AMT_REQ_CREDIT_BUREAU_YEAR'].fillna(0)

#checking the null values in the columns imputed with new values

app_data[['AMT_REQ_CREDIT_BUREAU_YEAR','AMT_REQ_CREDIT_BUREAU_MON','AMT_REQ_CREDIT_BUREAU_WEEK','AMT_REQ_CREDIT_BUREAU_DAY','AMT_REQ_CREDIT_BUREAU_HOUR','AMT_REQ_CREDIT_BUREAU_QRT']].isnull().sum()/len(app_data)*100


# ## b. Removing unwanted columns which are not relevant to our analysis.

# In[88]:


#Checking columns of the columns
app_data.columns


# In[89]:


#checking data in each column to see relevance to the problem statement
app_data.head()


# ### **After checking the values and data dictionary we can remove some of the columns safely fromt he dataframe.

# In[90]:


#Storing all unwanted columns in a list
unwanted_cols = ['FLAG_EMP_PHONE', 'FLAG_WORK_PHONE', 'FLAG_CONT_MOBILE', 'FLAG_PHONE','FLAG_EMAIL',
          'REGION_RATING_CLIENT','REGION_RATING_CLIENT_W_CITY', 'FLAG_EMAIL','DAYS_LAST_PHONE_CHANGE',
          'FLAG_DOCUMENT_2','REG_REGION_NOT_LIVE_REGION','REG_REGION_NOT_WORK_REGION',
          'LIVE_REGION_NOT_WORK_REGION','REG_CITY_NOT_WORK_CITY','FLAG_DOCUMENT_3', 'FLAG_DOCUMENT_4','FLAG_DOCUMENT_5',
          'FLAG_DOCUMENT_6','FLAG_DOCUMENT_7','FLAG_DOCUMENT_8','FLAG_DOCUMENT_9','FLAG_DOCUMENT_10',
          'FLAG_DOCUMENT_11','FLAG_DOCUMENT_12','FLAG_DOCUMENT_13', 'FLAG_DOCUMENT_14',
          'FLAG_DOCUMENT_15','FLAG_DOCUMENT_16','FLAG_DOCUMENT_17','FLAG_DOCUMENT_18',
                 'LIVE_CITY_NOT_WORK_CITY','FLAG_DOCUMENT_19', 'FLAG_DOCUMENT_20', 
                 'FLAG_DOCUMENT_21', 'EXT_SOURCE_2', 'EXT_SOURCE_3','REG_CITY_NOT_LIVE_CITY','REG_CITY_NOT_LIVE_CITY' ]
#droppinf the columns mentioned in the above list from app_data
app_data.drop(columns=unwanted_cols, inplace=True)
app_data.shape


# ### **See above the number of columns have reduced to 37 after removing unwanted columns.

# ### **Let's see the new dataframe columns

# In[91]:


app_data.info()


# ### **Now we need to fix errors in the dataset, for ex. after observing in the raw data 'DAYS_BIRTH', 'DAYS_EMPLOYED', 'DAYS_REGISTRATION' and 'DAYS_ID_PUBLISH' which had negative or mixed values and we need to impute them with absolute values for our analysis. Also, since the above columns with Days does not give a good sense of data it is better to change it to Years by dividing by ~365.
# 

# ## c. Data Correction and formatting

# In[92]:


#Checking to see the data with respect to columns with 'Days'
app_data[['DAYS_BIRTH' ,'DAYS_EMPLOYED' ,'DAYS_REGISTRATION' ,'DAYS_ID_PUBLISH']].describe()


# In[93]:


# converting negative DAYS_BIRTH value to positive value and converting days to years
app_data['DAYS_BIRTH']=(app_data['DAYS_BIRTH'].abs()/365).astype(int)
# converting negative DAYS_EMPLOYED value to positive value and converting days to years
app_data['DAYS_EMPLOYED']=(app_data['DAYS_EMPLOYED'].abs()/365).astype(int)
# converting negative DAYS_REGISTRATION value to positive value and converting days to years
app_data['DAYS_REGISTRATION']=(app_data['DAYS_REGISTRATION'].abs()/365).astype(int)
# converting negative DAYS_ID_PUBLISH value to positive value and converting days to years
app_data['DAYS_ID_PUBLISH']=(app_data['DAYS_ID_PUBLISH'].abs()/365).astype(int)

#renaming the columns from days to year
app_data.rename(columns={'DAYS_BIRTH':'YEARS_BIRTH' ,'DAYS_EMPLOYED':'YEARS_EMPLOYED' ,
    'DAYS_REGISTRATION':'YEARS_REGISTRATION' ,'DAYS_ID_PUBLISH':'YEARS_ID_PUBLISH'}, inplace=True)

#Checking data again
app_data[['YEARS_BIRTH' ,'YEARS_EMPLOYED' ,'YEARS_REGISTRATION' ,'YEARS_ID_PUBLISH']].describe()


# ### **After dropping unwanted columns and fixing some columns, we now check for datatypes of each columns and change their datatype based on the values they contain

# In[94]:


#Biining days if birth to categorize age of clients
app_data['YEARS_BIRTH_BINS']=pd.cut(app_data['YEARS_BIRTH'], bins=[20,25,35,60,100], labels=['Very_Young','Young', 'Middle_Age', 'Senior_Citizen'])


# In[95]:


app_data.nunique().sort_values()


# ### Looks like the ones with less unique values are categorical, we can fairly say until OCCUPATION_TYPE the fields are categorical. So, we will extract the index of theses columns.

# In[96]:


app_data.nunique().sort_values().index


# In[97]:


#changing some columns to category datatype
category_cols = ['FLAG_MOBIL', 'TARGET', 'NAME_CONTRACT_TYPE', 'CODE_GENDER', 'FLAG_OWN_CAR',
                    'FLAG_OWN_REALTY','AMT_REQ_CREDIT_BUREAU_HOUR', 'NAME_EDUCATION_TYPE',
                    'NAME_HOUSING_TYPE', 'NAME_FAMILY_STATUS', 'WEEKDAY_APPR_PROCESS_START',
                    'NAME_TYPE_SUITE', 'NAME_INCOME_TYPE', 'AMT_REQ_CREDIT_BUREAU_DAY',
                    'AMT_REQ_CREDIT_BUREAU_WEEK', 'DEF_60_CNT_SOCIAL_CIRCLE','DEF_30_CNT_SOCIAL_CIRCLE',
                    'AMT_REQ_CREDIT_BUREAU_QRT','CNT_FAM_MEMBERS','OCCUPATION_TYPE',
                    'HOUR_APPR_PROCESS_START','AMT_REQ_CREDIT_BUREAU_MON', 'AMT_REQ_CREDIT_BUREAU_YEAR',
                    'OBS_60_CNT_SOCIAL_CIRCLE','OBS_30_CNT_SOCIAL_CIRCLE','ORGANIZATION_TYPE']
for col in category_cols:
    app_data[col] = app_data[col].astype('category')
    
app_data.info()


# ### **Let's scheck gender column

# In[98]:


app_data['CODE_GENDER'].value_counts()


# ### **We need to impute the value of XNA to F as the F seems to be mode, so it can be done safely.

# In[99]:


#imputing gender value
app_data.loc[app_data['CODE_GENDER']=='XNA', 'CODE_GENDER'] = 'F'
app_data['CODE_GENDER'].value_counts()


# ### **Since it is hard to analyze the customer type based on continous variables we need to perform bnning of continuous variables.

# In[100]:


#  checking the'AMT_INCOME_TOTAL' and 'AMT_CREDIT' variables
app_data[['AMT_INCOME_TOTAL', 'AMT_CREDIT']].describe()


# In[101]:


#creating bins and ranges using quartiles
# AMT_INCOME_TOTAL
q1=app_data['AMT_INCOME_TOTAL'].quantile(0.25)
q2=app_data['AMT_INCOME_TOTAL'].quantile(0.50)
q3=app_data['AMT_INCOME_TOTAL'].quantile(0.75)
m=app_data['AMT_INCOME_TOTAL'].max()

# Binning AMT_INCOME_TOTAL into AMT_INCOME_TOTAL_bin so we don't loose data and have binned values
app_data['AMT_INCOME_RANGE'] = pd.cut(app_data['AMT_INCOME_TOTAL'],[q1, q2, q3,m ], labels = ['Low', 'medium', 'High'])
print(app_data.AMT_INCOME_RANGE.value_counts())


# In[102]:


#creating bins and ranges using quartiles
# AMT_INCOME_TOTAL
q1=app_data['AMT_CREDIT'].quantile(0.25)
q2=app_data['AMT_CREDIT'].quantile(0.50)
q3=app_data['AMT_CREDIT'].quantile(0.75)
m=app_data['AMT_CREDIT'].max()

# Binning AMT_INCOME_TOTAL into AMT_INCOME_TOTAL_bin so we don't loose data and have binned values
app_data['AMT_CREDIT_RANGE'] = pd.cut(app_data['AMT_CREDIT'],[q1, q2, q3,m ], labels = ['Low', 'medium', 'High'])
print(app_data.AMT_INCOME_RANGE.value_counts())


# # 2. Analysis

# In[103]:


#Initial analysis
plt.figure(figsize=(12,6)) 
sns.countplot(data=app_data,x='AMT_CREDIT_RANGE', hue='CODE_GENDER')
plt.xticks(rotation=90)
plt.legend(loc='upper right')
plt.show()


# ### **There is more female count in each credit range which kind of stems from the fact that the women are taking more loans.

# ## a.Finding outliers for different variables

# ### Checking for AMT_CREDIT

# In[104]:


sns.boxplot(app_data['AMT_CREDIT'])
plt.title('AMT_CREDIT')
plt.show()
# From box plot, we can conclude that there exists values which are above upper whisker(maximum) considered to be as outliers. 
Q1 = app_data['AMT_CREDIT'].quantile(0.25)
Q3 = app_data['AMT_CREDIT'].quantile(0.75)
IQR = Q3 - Q1
lowerwhisker1=(Q1 - 1.5 * IQR)
upperwhisker1=(Q3 + 1.5 * IQR)

print("The amount credited greater than {} can be considered as an outlier".format(upperwhisker1))


# ###  Checking for AMT INCOME TOTAL

# In[105]:


# AMT INCOME TOTAL varibale indictes the Income of the client.
#As we can see from the plot there is one value which is too high compared to others.hence it is an outlier.

sns.boxplot(app_data['AMT_INCOME_TOTAL'])
plt.show()


# ### CNT Children

# In[106]:


plt.boxplot(app_data['CNT_CHILDREN'])
plt.title('CNT_CHILDREN')
plt.show()
# From box plot, we can conclude that there exists values which are above upper whisker(maximum) considered to be as outliers. 
Q1 = app_data['CNT_CHILDREN'].quantile(0.25)
Q3 = app_data['CNT_CHILDREN'].quantile(0.75)
IQR = Q3 - Q1
lowerwhisker2=(Q1 - 1.5 * IQR)
upperwhisker2=(Q3 + 1.5 * IQR)

print("The values greater than {} are considered to be outliers,since count of children cannot be in decimals we can conclude that count greater than 3 can be an outlier".format(upperwhisker2))


# ### YEARS_EMPLOYED

# In[107]:


#YEARS_EMPLOYED variable indicates the employment experience before filling in the information?

sns.boxplot(app_data['YEARS_EMPLOYED'])
plt.show() 

#We can see from the plot below the outlier value is 1000 yrs. which makes the case for it being an outlier


# ### AMT ANNUITY

# In[108]:


#ANNUITY variable indicates the annuity paid by the customer

sns.boxplot(app_data.AMT_ANNUITY)
plt.show()

#We can see from the plot below the outlier value is 250,0000. which makes the case for it being an outlier


# ## b. Removing Outliers from the datset.

# In[109]:


#Excluding values outside 99%ile in each of the 4 variables

app_data=app_data[app_data.YEARS_EMPLOYED<np.nanpercentile(app_data['YEARS_EMPLOYED'], 99)]
app_data=app_data[app_data.AMT_INCOME_TOTAL<np.nanpercentile(app_data['AMT_INCOME_TOTAL'], 99)]
app_data=app_data[app_data.AMT_CREDIT<np.nanpercentile(app_data['AMT_CREDIT'], 99)]
app_data=app_data[app_data.AMT_ANNUITY<np.nanpercentile(app_data['AMT_ANNUITY'], 99)]


#dropping outliers for  CNT CHILDREN 
indexNames = app_data[(app_data['CNT_CHILDREN'] > 3)].index
app_data.drop(indexNames , inplace=True)

app_data.shape


# ## c. Checking data imbalance

# ### **Now, we need to divide the app_dat into two different dataframes based on target variable's value, app_data_0 and app_data_1 for values 0 and 1 respectively.
# ### Target variable (1 - client with payment difficulties: he/she had late payment more than X days on at least one of the first Y installments of the loan in our sample (for easyness we can call it default scenrios), 0 - all other cases(for easyness we can call it non-default scenarios))
# ### Then we need to check for imbalance of data

# In[110]:


# creating new datadrame for target=0
app_data_0 = app_data[app_data['TARGET']==0]
app_data_0.head()


# In[111]:


app_data_0.shape


# In[112]:


# creating new datadrame for target=1
app_data_1 = app_data[app_data['TARGET']==1]
app_data_1.head()


# In[113]:


app_data_1.shape


# In[114]:


app_data['TARGET'].value_counts(normalize=True)*100


# In[115]:


#checking the distribution of target variable
ax = sns.countplot(app_data['TARGET'])
plt.xlabel("TARGET Value")
plt.ylabel("Count of TARGET value")
plt.title("Distribution of TARGET Variable")
total = float(len(app_data))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
    
plt.show()


# ### **Basically, the percentages of 0 and 1 are 91.21 and 8.78 respectively. This is a higlhy imbalanced data set. We will now find the correlation between different variables for both dataframes with target=1 and target=0

# ## d.1 Univariate Analysis for numerical variables

# ###  Age of the Client

# In[116]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.boxplot(app_data_0['YEARS_BIRTH'])
plt.title('Customer without payment difficulties')

plt.subplot(1,2,2)
ax = sns.boxplot(app_data_1['YEARS_BIRTH'])
plt.title('Customer with payment difficulties')
plt.show()


# ### **From the above box plot we can note that customer without payment difficulties and coustomer with payment difficulties have age in between 30 to 50 years with not much difference in median age. Nothing much conclusive from the age group.

# ### EMPLOYED YEARS

# In[117]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.boxplot(app_data_0[app_data_0['YEARS_EMPLOYED']<1000]['YEARS_EMPLOYED'])
plt.title('Customer without payment difficulties')

plt.subplot(1,2,2)
ax = sns.boxplot(app_data_1[app_data_1['YEARS_EMPLOYED']<1000]['YEARS_EMPLOYED'])
plt.title('Customer with payment difficulties')
plt.show()


# ### **From the above box plot we can note that customer without payment difficulties have employment years in between 2 to 8 years , And coustomer with payment difficulties have employment years in between 1 to 6. There is a slight indication that people having more number of years employed have less trouble paying the loans.
# 

# ### Amount annuity

# In[118]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.boxplot(app_data_0['AMT_ANNUITY'])
plt.title('Customer without payment difficulties')

plt.subplot(1,2,2)
ax = sns.boxplot(app_data_1['AMT_ANNUITY'])
plt.title('Customer with payment difficulties')
plt.show()


# ### **Most of the customer be it the ones who have difficulty in paying loans and not having difficulty paying loans have annuity amount between 15k to 35k, not much conclusive inference from the variable.

# ### CHILDREN COUNT

# In[119]:


#Children count customers without Loan Non-Payment Difficulties
a0 = app_data_0["CNT_CHILDREN"].value_counts()
df = pd.DataFrame({'labels': a0.index,'values': a0.values})
df.plot(kind='pie',labels=a0.index,y='values',autopct='%1.1f%%', title='Children count of Customer without payment difficulties')


# In[120]:


#Children count custimers with Loan Non-Payment Difficulties
a0 = app_data_1["CNT_CHILDREN"].value_counts()
df = pd.DataFrame({'labels': a0.index,'values': a0.values})
df.plot(kind='pie',labels=a0.index,y='values',autopct='%1.1f%%', title='Children count of Customer with payment difficulties')


# ### **In both the cases the group with no children had highest percentage. So there doesn't seem to be much inference from the count of children.

# ### Rest of Numerical variables

# In[121]:


#considering 10 continous numerical columns
continous_columns=['AMT_GOODS_PRICE','CNT_FAM_MEMBERS','YEARS_ID_PUBLISH','AMT_CREDIT']
plt.figure(figsize=(22,25))
for i in (enumerate(continous_columns)):
    plt.subplot(len(continous_columns)//2,2,i[0]+1)
    sns.distplot(app_data_1[i[1]].dropna(),hist=False,label='Target : Customer with payment difficulties')
    sns.distplot(app_data_0[i[1]].dropna(),hist=False,label='Target : Customer without payment difficulties')
    plt.legend()    
plt.show()    


# ### **From the above graphs we can conclude 2 major inferences:
# ### 1. For AMT_GOODS_PRICE above 500,000 the customer didn't have payment difficulties.
# ### 2. For customers with larger family count the customers with payment difficulty increases

# ## d.2 Univariate Analysis for categorical variables

# ### Contract Type

# In[122]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.countplot(app_data_0['NAME_CONTRACT_TYPE'])
plt.title('Customer without payment difficulties')

plt.subplot(1,2,2)
ax = sns.countplot(app_data_1['NAME_CONTRACT_TYPE'])
plt.title('Customer with payment difficulties')
plt.show()


# ### **In the above graph, we can see that the customer without payment and customer with payment difficulties both are taking cash loans.

#  ### Gender Distribution
# 

# In[123]:


#Gender Distibution of Loan Non-Payment Difficulties
a0 = app_data_0["CODE_GENDER"].value_counts()
df = pd.DataFrame({'labels': a0.index,'values': a0.values})
df.plot(kind='pie',labels=a0.index,y='values',autopct='%1.1f%%', title='Gender Distribution of Customer without payment difficulties')


# In[124]:


# Gender Distibution of Loan Payment Difficulties
a1 = app_data_1["CODE_GENDER"].value_counts()
df = pd.DataFrame({'labels': a1.index,'values': a1.values})
df.plot(kind='pie',labels=a0.index,y='values',autopct='%1.1f%%', title='Gender Distribution of Customer with payment difficulties')


# 
# ### **We see more female applying for loans than males and hence the more number of female defaulters as well. But the rate of defaulting of FEMALE is much lower compared to their MALE counterparts. it segment which has difficulties in payment or not women have higher proportion without having difficulties paying loan than the with haing difficulties paying off the loan.

# ### Education type

# In[126]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.countplot(app_data_0['NAME_EDUCATION_TYPE'])
plt.title('Customer without payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_0))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')

plt.subplot(1,2,2)
ax = sns.countplot(app_data_1['NAME_EDUCATION_TYPE'])
plt.title('Customer with payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_1))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
    
plt.show()


# ### **Above, we can see that the customer having payment difficulties in secondary/ secondary special and customer with higher education are able to pay more loans without difficulties.

# ### Occupation type

# In[127]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.countplot(app_data_0['OCCUPATION_TYPE'])
plt.title('Customer without payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_0))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')

plt.subplot(1,2,2)
ax = sns.countplot(app_data_1['OCCUPATION_TYPE'])
plt.title('Customer with payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_1))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
plt.show()


# ### **Above we see that labourers are having more difficulties in repaying the loan along with the sales staff. Managers and high tech skill staff had less difficulty in paying loans.
# 

# ### NAME_INCOME_TYPE

# In[128]:


# NAME_INCOME_TYPE
# for TARGET=0
app_data_0.NAME_INCOME_TYPE.value_counts(normalize=True).plot.barh()
plt.title('Customer without payment difficulties')
plt.show()
# for TARGET=1
app_data_1.NAME_INCOME_TYPE.value_counts(normalize=True).plot.barh()
plt.title('Customer with payment difficulties')
plt.show()
# from the graphs below, we can conclude that
# Pensioner of not default case are high in number compared to Pensioner of default case.
#It seems there exists both loss and profit due to Pension people to the Bank.
# It also shows that majority of defaulters income type is working.
#and at the same time there is good income to bank from working people.


# ### **We can notice that the students don't default. The reason could be they are not required to pay during the time they are students.We can also see that the BusinessMen never default. Most of the loans are distributed to working class people. We also see that working class people contribute 65% to non defaulters while they contribute to 70% of the defaulters. Clearly, the chances of defaulting are more in their case.

# ### NAME_FAMILY_STATUS

# In[129]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.countplot(app_data_0['NAME_FAMILY_STATUS'])
plt.title('Customer without payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_0))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
    
plt.subplot(1,2,2)
ax = sns.countplot(app_data_1['NAME_FAMILY_STATUS'])
plt.title('Customer with payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_1))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')


plt.show()


# ### **Married people tend to apply for more loans comparatively.But from the graph we see that Single/non Married people contribute 15.4% to Non Defaulters and 19% to the defaulters. So there is more risk associated with them.

# ### NAME_HOUSING_TYPE

# In[130]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.countplot(app_data_0['NAME_HOUSING_TYPE'])
plt.title('Customer without payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_0))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
    
plt.subplot(1,2,2)
ax = sns.countplot(app_data_1['NAME_HOUSING_TYPE'])
plt.title('Customer with payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_1))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
plt.show()


# ### **It is clear from the graph that people who have House/Appartment, tend to apply for more loans. People living with parents tend to default more often when compared with others.One reason for the people living with their parents is they need to share expenses of the parents and hence not able to repay loans.

# ### AMT_INCOME_RANGE

# In[131]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.countplot(app_data_0['AMT_INCOME_RANGE'])
plt.title('Customer without payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_0))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
    
plt.subplot(1,2,2)
ax = sns.countplot(app_data_1['AMT_INCOME_RANGE'])
plt.title('Customer with payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_1))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
plt.show()


# ### **The High income group tend to default less often. They contribute 19.9% to the total number of defaulters, while they contribute 24% to the Non-Defaulters.
# 

# ### FLAG_OWN_CAR

# In[132]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.countplot(app_data_0['FLAG_OWN_CAR'])
plt.title('Customer without payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_0))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
    
plt.subplot(1,2,2)
ax = sns.countplot(app_data_1['FLAG_OWN_CAR'])
plt.title('Customer with payment difficulties')
plt.xticks(rotation=90)
total = float(len(app_data_1))
for p in ax.patches:
    percentage = '{:.1f}%'.format(100 * p.get_height()/total)
    x = p.get_x() + p.get_width()
    y = p.get_height()
    ax.annotate(percentage, (x, y),ha='center')
plt.show()


# ### **We can see that people with cars contribute 62.7% to customers not having difficulties in payment while 67.8% to the ones having payment difficulties. We can conclude that. While people who have car default more often, the reason could be there are simply more people without cars. Looking at the percentages in both the charts, we can conclude that the rate of default of people having car is low compared to people who don't.

# ## e. Bivariate Analysis

# ##  Finding Correlation before performing bivariate analysis

# In[133]:


# for target variable=0
plt.figure(figsize=(12,8)) 
sns.heatmap(app_data_0.corr(), annot=True, cmap="coolwarm")
plt.title('Correlation matrix for target variable 0')
plt.show()


# In[134]:


# now we need to find top 10 correlations
corr0 = app_data_0.corr()
corr_df0 = corr0.where(np.triu(np.ones(corr0.shape), k=1).astype(np.bool))
corr_df0 = corr_df0.unstack().reset_index().dropna(subset = [0])
corr_df0.columns = ['VAR1', 'VAR2', 'Correlation_Value']
corr_df0['Corr_abs'] = abs(corr_df0['Correlation_Value'])
corr_df0.sort_values(by = "Corr_abs", ascending =False, inplace = True)
corr_df0.head(10)


# In[135]:


# for target variable=1
plt.figure(figsize=(12,8)) 
sns.heatmap(app_data_1.corr(), annot=True, cmap="coolwarm")
plt.title('Correlation matrix for target variable 1')
plt.show()


# In[136]:


# now we need to find top 10 correlations
corr1 = app_data_1.corr()
corr_df1 = corr1.where(np.triu(np.ones(corr1.shape), k=1).astype(np.bool))
corr_df1 = corr_df1.unstack().reset_index().dropna(subset = [0])
corr_df1.columns = ['VAR1', 'VAR2', 'Correlation_Value']
corr_df1['Corr_abs'] = abs(corr_df1['Correlation_Value'])
corr_df1.sort_values(by = "Corr_abs", ascending =False, inplace = True)
corr_df1.head(10)


# ### e.1 Numerical-Numerical bivariate analysis

# ### Selecting 3 variables AMT_ANNUITY,AMT_INCOME_TOTAL,AMT_CREDIT,AMT_GOODS_PRICE for bivariate analysis based on correlation shown above.

# In[137]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.scatterplot(data=app_data_0, x='AMT_GOODS_PRICE',y='AMT_CREDIT')
plt.title('Customer without payment difficulties')

plt.subplot(1,2,2)
ax = sns.scatterplot(data=app_data_1, x='AMT_GOODS_PRICE',y='AMT_CREDIT')
plt.title('Customer with payment difficulties')
plt.show()


# ### **The above graph shows that clients with high amount good price and credit amount will have less difficulty to pay off loans.

# In[138]:


plt.figure(figsize=(20,8)) 

plt.subplot(1,2,1)
ax = sns.scatterplot(data=app_data_0, x='AMT_INCOME_TOTAL',y='AMT_CREDIT')
plt.title('Customer without payment difficulties')

plt.subplot(1,2,2)
ax = sns.scatterplot(data=app_data_1, x='AMT_INCOME_TOTAL',y='AMT_CREDIT')
plt.title('Customer with payment difficulties')
plt.show()


# ### **The above analysis shows that customers with income total between 200k to 300k and amount credit between 500k and 1 million are the customer segment that don't have payment difficulties and are safe bet.

# ## Infrences from the univariate and bivariate analysis of application data.
# 
# ### People having more number of years employed have less trouble paying the loans.
# ### There doesn't seem to be much inference from the count of children of the customer.
# ### For goods price above 500,000 the customer didn't have payment difficulties.
# ### For customers with larger family count the payment difficulty increases.
# ### Customer having payment difficulties in secondary/ secondary special and customer with higher education are able to pay more loans without difficulties. So the companies can focus on giving loans to people with higher education.
# ### We can conclude that the rate of default of people having car is low compared to people who don’t.
# ### Clients with high amount good price and credit amount will have less difficulty to pay off loans.
# ### Customers with income total between 200k to 300k and amount credit between 500k and 1 million are the customer segment that don't have payment difficulties and are safe bet.
# 
# ### People with Medium total income are more likely to default and high income less probable to default.
# ### People with high Credit amount are less likely to default
# ### People with house or apartment tend to take more loans, people on rent are more likely to default
# ### We can say more married people tend to take more Loan as compared to other categories.
# ### we can conclude that secondary/special educated people are applying loans in high in number.
# ### People who don't own a car take more loans
# ### Females take more loans, and have lower default ratio as compared to men.
# ### People tend to take more cash loans, and default percentage of revolving loans is less.
# ### Banks should focus more on contract type ‘Student’ ,’pensioner’ and ‘Businessman’.
# 
# 

# # 3. Analysis using previous data of clients

# In[139]:


#checking the previous data
prev_data.head(5)


# In[140]:


prev_data.shape


# ## a. Cleaning previous data

# ### Find null values for each column and removing columns with null >40%

# In[141]:


Find_null = prev_data.isnull().sum()/len(prev_data)*100
Find_null.sort_values(ascending = False).head(50)


# In[142]:


Remove_null = Find_null.sort_values(ascending = False)
Remove_null = Remove_null[Remove_null.values > 40]
len(Remove_null)


# In[143]:


remove_list = Remove_null.index.tolist()
prev_data.drop(labels =remove_list,axis =1,inplace=True)
prev_data.shape


# In[144]:


#checking previous data after removing few columns with null values
prev_data.head(5)


# ## b. Univariate Analysis of previous data

# ### NAME_CONTRACT_TYPE

# In[145]:


plt.style.use('ggplot')
sns.despine
fig,ax = plt.subplots(1,1,figsize=(15,5))

sns.countplot(x='NAME_CONTRACT_TYPE',data = prev_data, ax=ax, hue='NAME_CONTRACT_STATUS')
ax.set_ylabel('Total Counts')
ax.set_title('Distribution of NAME_CONTRACT_TYPE',fontsize=15)
ax.set_xticklabels(ax.get_xticklabels(), rotation=40, ha="right")

plt.show()


# ### **From the above chart, we can infer that, most of the applications are for 'Cash loan' and 'Consumer loan'. Although the cash loans are refused more often than others.

# ### NAME_PAYMENT_TYPE

# In[150]:


plt.style.use('ggplot')
sns.despine
fig,ax = plt.subplots(1,1,figsize=(15,5))

sns.countplot(x='NAME_PAYMENT_TYPE',data = prev_data, ax=ax, hue='NAME_CONTRACT_STATUS')
ax.set_ylabel('Total Counts')
ax.set_title('Distribution of NAME_PAYMENT_TYPE',fontsize=15)
ax.set_xticklabels(ax.get_xticklabels(), rotation=40, ha="right")

plt.show()


# ### **From the above chart, we can infer that most of the clients chose to repay the loan using the 'Cash through the bank' option. We can also see that 'Non-Cash from your account' & 'Cashless from the account of the employee' options are not at all popular in terms of loan repayment amongst the customers.

# ### NAME_CLIENT_TYPE

# In[151]:


plt.style.use('ggplot')
sns.despine
fig,ax = plt.subplots(1,1,figsize=(15,5))

sns.countplot(x='NAME_CLIENT_TYPE',data = prev_data, ax=ax, hue='NAME_CONTRACT_STATUS')
ax.set_ylabel('Total Counts')
ax.set_title('Distribution of NAME_CLIENT_TYPE',fontsize=15)
ax.set_xticklabels(ax.get_xticklabels(), rotation=40, ha="right")

plt.show()


# ### **Most of the loan applications are from repeat customers, out of the total applications 70% of customers are repeaters. They also get refused most often.

# ## c. Bivariate Analysis

# ### AMT_ANNUITY Vs NAME_CONTRACT_STATUS

# In[152]:


plt.style.use('seaborn-poster')
fig,ax = plt.subplots(1,1,figsize=(10,8))

sns.boxplot(x='NAME_CONTRACT_STATUS',y = 'AMT_ANNUITY', data = prev_data)
ax.set_ylabel('AMT_ANNUITY')
ax.set_xlabel('NAME_CONTRACT_STATUS')

ax.set_title('AMT_ANNUITY Vs NAME_CONTRACT_STATUS',fontsize=15)
ax.set_xticklabels(ax.get_xticklabels(), rotation=40, ha="right")
plt.show() 
  


# ### **From the above plot we can see that loan application for people with lower AMT_ANNUITY gets canceled or Unused most of the time. We also see that applications with too high AMT ANNUITY also got refused more often than others.
# 
# 

# ### AMT_CREDIT Vs NAME_CONTRACT_STATUS

# In[153]:


plt.style.use('ggplot')
fig,ax = plt.subplots(1,1,figsize=(10,8))

sns.boxplot(x='NAME_CONTRACT_STATUS',y = 'AMT_CREDIT', data = prev_data)
ax.set_ylabel('AMT_ANNUITY')
ax.set_xlabel('NAME_CONTRACT_STATUS')

ax.set_title('AMT_CREDIT Vs NAME_CONTRACT_STATUS',fontsize=15)
ax.set_xticklabels(ax.get_xticklabels(), rotation=40, ha="right")
plt.show() 
  


# ### **We can infer that when the AMT_CREDIT is too low, it get's cancelled/unused most of the time.

# ## d. Merging application and previous client data on SK_ID_CURR

# In[154]:


#Merging data
Merged_data = pd.merge(app_data, prev_data, how='left', on=['SK_ID_CURR'])
Merged_data.shape


# In[155]:


Merged_data.info()


# ## e. Analysis on merged data

# ### **For this we can create pivot tables and fin how different variables perform against the approval rates for the loan.

# ### FLAG_OWN_CAR vs Loan Approval

# In[156]:


plt.style.use('ggplot')
sns.despine
pivot_data = Merged_data.pivot_table(values='SK_ID_CURR', 
                  index='FLAG_OWN_CAR',
                  columns='NAME_CONTRACT_STATUS',
                  aggfunc='count')
pivot_data=pivot_data.div(pivot_data.sum(axis=1),axis='rows')*100
sns.set()
pivot_data.plot(kind='bar',stacked=True,figsize=(15,5), colormap = 'plasma')
plt.title( 'FLAG_OWN_CAR vs Loan Approval')
plt.xlabel('FLAG_OWN_CAR')
plt.ylabel('NAME_CONTRACT_STATUS %')
plt.show()


# ### **We observe that car ownership doesn't have any effect on application approval or rejection. Butit was seen earlier that the people who has a car has lesser chances of default. Car ownership can be checked while approving a loan amount.

# ### TARGET vs Loan Approval

# In[157]:


plt.style.use('ggplot')
sns.despine
pivot_data = Merged_data.pivot_table(values='SK_ID_CURR', 
                  index='TARGET',
                  columns='NAME_CONTRACT_STATUS',
                  aggfunc='count')
pivot_data=pivot_data.div(pivot_data.sum(axis=1),axis='rows')*100
sns.set()
pivot_data.plot(kind='bar',stacked=True,figsize=(15,5), colormap = 'plasma')
plt.title( 'TARGET vs Loan Approval')
plt.xlabel('TARGET')
plt.ylabel('NAME_CONTRACT_STATUS %')
plt.show()


# ### **We observe that the people who were approved for a loan earlier, didn't have issues with loan payment less often where as people who were refused a loan earlier have higher chances of defaulting.

# ### GENDER vs Loan Approval

# In[158]:


plt.style.use('ggplot')
sns.despine
pivot_data = Merged_data.pivot_table(values='SK_ID_CURR', 
                  index='CODE_GENDER',
                  columns='NAME_CONTRACT_STATUS',
                  aggfunc='count')
pivot_data=pivot_data.div(pivot_data.sum(axis=1),axis='rows')*100
sns.set()
pivot_data.plot(kind='bar',stacked=True,figsize=(15,5), colormap = 'plasma')
plt.title( 'CODE_GENDER vs Loan Approval')
plt.xlabel('CODE_GENDER')
plt.ylabel('NAME_CONTRACT_STATUS %')
plt.show()


# ### **We observe that code gender doesn't have any effect on application approval as well as rejection.But as observed earlier, females have lesser chances of default compared to males. The bank can emphasize on giving loans to more females.

# ## Infrences from the previous data and merged data:
# 
# ### Most of the clients chose to repay the loan using the 'Cash through the bank' option. We can also see that 'Non-Cash from your account' & 'Cashless from the account of the employee' options are not at all popular in terms of loan repayment amongst the customers. 
# ### Most of the applications are for 'Cash loan' and 'Consumer loan'. Although the cash loans are refused more often than others. 
# ### Most of the loan applications are from repeat customers, out of the total applications 70% of customers are repeaters. They also get refused most often.
# ### Loan application for people with lower AMT_ANNUITY gets canceled or Unused most of the time. We also see that applications with too high AMT ANNUITY also got refused more often than others.
# ### When the credit amount is too low, it get's cancelled/unused most of the time.
# ### We observe that the people who were approved for a loan earlier, didn't have issues with loan payment less often where as people who were refused a loan earlier have higher chances of defaulting.
# 

# In[ ]:




